<template>
  <h1>you`re wrong!</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>